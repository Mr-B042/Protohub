# Main Hanger 2026 — Order & Logistics Data

Source workbook: `Main_Hanger_2026.xlsx` (ProTools Hardware POD operation).
This document describes the structure of each sheet so an AI assistant can reason about the data.

---

## Sheet: `Dispatch_Logistics`

**Purpose:** Master order log. Every customer order with delivery, logistics, and remittance status.

**Shape:** 364 rows × 16 columns

**Columns:**

- `Order ID` — 355 non-null values. Examples: 20260223-Anthony Mario, 20260223-Ejinyere Godwin, 20260223-Justina
- `Order Date

` — 355 non-null values. Examples: 2026-02-23 00:00:00, 2026-02-23 00:00:00, 2026-02-23 00:00:00
- `Customer Name` — 355 non-null values. Examples: Anthony Mario, Ejinyere Godwin, Justina
- `State` — 355 non-null values. Examples: Lagos, Delta, Abuja
- `Product` — 364 non-null values. Examples: Hanger, Hanger, Hanger
- `Quantity` — 345 non-null values. Examples: 20.0, 5.0, 10.0
- `Free Towel Qty` — 0 non-null values. Examples: (empty)
- `Order Amount` — 346 non-null values. Examples: 65500.0, 35000.0, 45000.0
- `Logistics` — 309 non-null values. Examples: Agent, Korrect, Gilgal Log.
- `Logistics Cost (Manual Entry)` — 180 non-null values. Examples: 4000.0, 3000.0, 3500.0
- `Amount to Remit` — 178 non-null values. Examples: 61500.0, 32000.0, 41500.0
- `Total Cost of Goods` — 178 non-null values. Examples: 40500.0, 10500.0, 20500.0
- `Gross Profit` — 178 non-null values. Examples: 21000.0, 21500.0, 21000.0
- `Delivery Status` — 350 non-null values. Examples: Delivered, Delivered, Delivered
- `Remittance Status` — 174 non-null values. Examples: Paid, Paid, Paid
- `Unnamed: 15` — 9 non-null values. Examples: send out once abuja recieve, 2500 for pickup, 3k paid to stockeeper

**Sample rows (first 5):**

| Order ID                 | Order Date          | Customer Name   | State   | Product   |   Quantity |   Free Towel Qty |   Order Amount | Logistics   |   Logistics Cost (Manual Entry) |   Amount to Remit |   Total Cost of Goods |   Gross Profit | Delivery Status   | Remittance Status   |   Unnamed: 15 |
|                          |                     |                 |         |           |            |                  |                |             |                                 |                   |                       |                |                   |                     |               |
|                          |                     |                 |         |           |            |                  |                |             |                                 |                   |                       |                |                   |                     |               |
|:-------------------------|:--------------------|:----------------|:--------|:----------|-----------:|-----------------:|---------------:|:------------|--------------------------------:|------------------:|----------------------:|---------------:|:------------------|:--------------------|--------------:|
| 20260223-Anthony Mario   | 2026-02-23 00:00:00 | Anthony Mario   | Lagos   | Hanger    |         20 |              nan |          65500 | Agent       |                            4000 |             61500 |                 40500 |          21000 | Delivered         | Paid                |           nan |
| 20260223-Ejinyere Godwin | 2026-02-23 00:00:00 | Ejinyere Godwin | Delta   | Hanger    |          5 |              nan |          35000 | Korrect     |                            3000 |             32000 |                 10500 |          21500 | Delivered         | Paid                |           nan |
| 20260223-Justina         | 2026-02-23 00:00:00 | Justina         | Abuja   | Hanger    |         10 |              nan |          45000 | Gilgal Log. |                            3500 |             41500 |                 20500 |          21000 | Delivered         | Paid                |           nan |
| 20260224-Engr T          | 2026-02-24 00:00:00 | Engr T          | Delta   | Hanger    |         20 |              nan |          65500 | Korrect     |                            4500 |             61000 |                 40500 |          20500 | Delivered         | Paid                |           nan |
| 20260224-HECOS           | 2026-02-24 00:00:00 | HECOS           | Delta   | Hanger    |         10 |              nan |          45500 | Korrect     |                            3500 |               nan |                   nan |            nan | Rescheduled       | Paid                |           nan |

---

## Sheet: `Daily_Logistics_List`

**Purpose:** Daily logistics dispatch tracker (mostly empty / live sheet).

**Shape:** 4 rows × 1 columns

**Columns:**

- `Unnamed: 0` — 2 non-null values. Examples: 2026-05-03 00:00:00, Logistics

**Sample rows (first 5):**

| Unnamed: 0          |
|:--------------------|
| 2026-05-03 00:00:00 |
| nan                 |
| nan                 |
| Logistics           |

---

## Sheet: `Logistics_Summary`

**Purpose:** Aggregated daily summary per logistics partner (revenue, cost, profit).

**Shape:** 167 rows × 9 columns

**Columns:**

- `Order Date (per logistics per day, manually)` — 139 non-null values. Examples: 2026-02-23 00:00:00, 2026-02-23 00:00:00, 2026-02-23 00:00:00
- `Logistics` — 131 non-null values. Examples: Agent, Gilgal Log., Korrect
- `Delivered Orders` — 167 non-null values. Examples: 1, 1, 1
- `Total Revenue` — 151 non-null values. Examples: 65500.0, 45000.0, 35000.0
- `Total Logistics Cost` — 151 non-null values. Examples: 4000.0, 3500.0, 3000.0
- `Total Amount to be Remitted` — 155 non-null values. Examples: 61500.0, 41500.0, 32000.0
- `Total Gross Profit` — 154 non-null values. Examples: 21000.0, 21000.0, 21500.0
- `Total Actually Remitted (Manual)` — 0 non-null values. Examples: (empty)
- `Difference` — 155 non-null values. Examples: 61500.0, 41500.0, 32000.0

**Sample rows (first 5):**

| Order Date (per logistics per day, manually)   | Logistics   |   Delivered Orders |   Total Revenue |   Total Logistics Cost |   Total Amount to be Remitted |   Total Gross Profit |   Total Actually Remitted (Manual) |   Difference |
|:-----------------------------------------------|:------------|-------------------:|----------------:|-----------------------:|------------------------------:|---------------------:|-----------------------------------:|-------------:|
| 2026-02-23 00:00:00                            | Agent       |                  1 |           65500 |                   4000 |                         61500 |                21000 |                                nan |        61500 |
| 2026-02-23 00:00:00                            | Gilgal Log. |                  1 |           45000 |                   3500 |                         41500 |                21000 |                                nan |        41500 |
| 2026-02-23 00:00:00                            | Korrect     |                  1 |           35000 |                   3000 |                         32000 |                21500 |                                nan |        32000 |
| 2026-02-24 00:00:00                            | Korrect     |                  1 |           65500 |                   4500 |                         61000 |                20500 |                                nan |        61000 |
| 2026-02-24 00:00:00                            | Gilgal Log. |                  1 |           45500 |                   4000 |                         41500 |                21000 |                                nan |        41500 |

---

## Sheet: `Product_Cost_Table`

**Purpose:** Cost-of-goods reference table for each product SKU.

**Shape:** 1 rows × 2 columns

**Columns:**

- `Product` — 1 non-null values. Examples: Hanger
- `Cost` — 1 non-null values. Examples: 2000

**Sample rows (first 5):**

| Product   |   Cost |
|:----------|-------:|
| Hanger    |   2000 |

---

## Sheet: `Ad_Expenses`

**Purpose:** Daily ad spend (Facebook/Meta).

**Shape:** 43 rows × 6 columns

**Columns:**

- `Date` — 43 non-null values. Examples: 2026-02-23 00:00:00, 2026-02-24 00:00:00, 2026-02-25 00:00:00
- `Amount` — 36 non-null values. Examples: 20110.0, 12870.0, 9840.14
- `Unnamed: 2` — 1 non-null values. Examples: 4,628.09 toolbox
- `Unnamed: 3` — 0 non-null values. Examples: (empty)
- `Unnamed: 4` — 0 non-null values. Examples: (empty)
- `Unnamed: 5` — 1 non-null values. Examples: a

**Sample rows (first 5):**

| Date                |   Amount |   Unnamed: 2 |   Unnamed: 3 |   Unnamed: 4 |   Unnamed: 5 |
|:--------------------|---------:|-------------:|-------------:|-------------:|-------------:|
| 2026-02-23 00:00:00 | 20110    |          nan |          nan |          nan |          nan |
| 2026-02-24 00:00:00 | 12870    |          nan |          nan |          nan |          nan |
| 2026-02-25 00:00:00 |  9840.14 |          nan |          nan |          nan |          nan |
| 2026-02-26 00:00:00 |  6537.47 |          nan |          nan |          nan |          nan |
| 2026-02-27 00:00:00 | 13210    |          nan |          nan |          nan |          nan |

---

## Sheet: `Other_Expenses`

**Purpose:** Miscellaneous business expenses (waybill, storekeeper fees, etc.).

**Shape:** 1 rows × 3 columns

**Columns:**

- `Date` — 1 non-null values. Examples: 2026-03-17 00:00:00
- `Expenses Type` — 1 non-null values. Examples: North waybill/storekeeper fees
- `Amount` — 1 non-null values. Examples: 12500

**Sample rows (first 5):**

| Date                | Expenses Type                  |   Amount |
|:--------------------|:-------------------------------|---------:|
| 2026-03-17 00:00:00 | North waybill/storekeeper fees |    12500 |

---

## Sheet: `Dashboard`

**Purpose:** Single-date dashboard (lookup view, not a data table).

**Shape:** 10 rows × 3 columns

**Columns:**

- `Unnamed: 0` — 0 non-null values. Examples: (empty)
- `Unnamed: 1` — 8 non-null values. Examples: Select Date, Delivered Orders, Total Revenue
- `Unnamed: 2` — 8 non-null values. Examples: 2026-05-02 00:00:00, 2, 91000

**Sample rows (first 5):**

|   Unnamed: 0 | Unnamed: 1       | Unnamed: 2          |
|-------------:|:-----------------|:--------------------|
|          nan | Select Date      | 2026-05-02 00:00:00 |
|          nan | nan              | nan                 |
|          nan | nan              | nan                 |
|          nan | Delivered Orders | 2                   |
|          nan | Total Revenue    | 91000               |

---

## Sheet: `SM`

**Purpose:** Social Media sales closer log (orders closed via WhatsApp/SM by staff).

**Shape:** 7 rows × 9 columns

**Columns:**

- `S/N` — 7 non-null values. Examples: 1, 2, 3
- `Order Date` — 4 non-null values. Examples: 2026-03-04 00:00:00, 2026-03-12 00:00:00, 2026-03-14 00:00:00
- `Full Name` — 4 non-null values. Examples: Godwin Azariah, SAMUEL EKEMAM EKEMAM, Degababa
- `Active Phone Number` — 0 non-null values. Examples: (empty)
- `Whatsapp Number (For backup contact)` — 0 non-null values. Examples: (empty)
- `States` — 4 non-null values. Examples: Rivers, IMO, Lagos
- `Single Package ` — 5 non-null values. Examples: 2nd Week Of MARCH
Monday 09/3/2026, 5 pcs = ₦35,500 Hanger, 7 pcs = ₦35,500 Hanger
- `Staff  Bonus` — 3 non-null values. Examples: 2500.0, 2500.0, 2500.0
- `Customer Availabilty /Delivery Status` — 4 non-null values. Examples: Delivered , Delivered , Delivered 

**Sample rows (first 5):**

|   S/N | Order Date          | Full Name            |   Active Phone Number |   Whatsapp Number (For backup contact) | States   | Single Package           |   Staff  Bonus | Customer Availabilty /Delivery Status   |
|------:|:--------------------|:---------------------|----------------------:|---------------------------------------:|:---------|:-------------------------|---------------:|:----------------------------------------|
|     1 | NaT                 | nan                  |                   nan |                                    nan | nan      | 2nd Week Of MARCH        |            nan | nan                                     |
|       |                     |                      |                       |                                        |          | Monday 09/3/2026         |                |                                         |
|     2 | 2026-03-04 00:00:00 | Godwin Azariah       |                   nan |                                    nan | Rivers   | 5 pcs = ₦35,500 Hanger   |           2500 | Delivered                               |
|     3 | 2026-03-12 00:00:00 | SAMUEL EKEMAM EKEMAM |                   nan |                                    nan | IMO      | 7 pcs = ₦35,500 Hanger   |           2500 | Delivered                               |
|     4 | 2026-03-14 00:00:00 | Degababa             |                   nan |                                    nan | Lagos    | 5 pcs = ₦35,500 Hanger   |           2500 | Delivered                               |
|     5 | 2026-03-09 00:00:00 | Kolawole Ogunkoya    |                   nan |                                    nan | Lagos    | 20pcs for #65,500 hanger |            nan | Will get back to us                     |

---

